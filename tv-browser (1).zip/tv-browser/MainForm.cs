using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace TVBrowser;

sealed class MainForm : Form
{
    private readonly AppConfig _cfg = AppConfig.Load();
    private readonly WebView2 _web = new()
    {
        Dock = DockStyle.Fill,
        DefaultBackgroundColor = Color.FromArgb(7, 8, 12)
    };
    private readonly Uri _home;

    public MainForm()
    {
        _home = new Uri(_cfg.HomeUrl);
        Text = "TV Browser";
        BackColor = Color.FromArgb(7, 8, 12);
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = Screen.PrimaryScreen!.Bounds;   // covers the whole screen, taskbar included
        TopMost = true;
        Controls.Add(_web);
        Shown += async (_, _) => await InitAsync();
    }

    private async Task InitAsync()
    {
        try
        {
            // logins and cookies are kept here so you only sign in once
            var dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TVBrowser");
            var options = new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required");
            var env = await CoreWebView2Environment.CreateAsync(null, dataDir, options);
            await _web.EnsureCoreWebView2Async(env);
        }
        catch (Exception ex)
        {
            TopMost = false;
            MessageBox.Show(this,
                "TV Browser couldn't start its web engine.\n\n" + ex.Message +
                "\n\nInstall the Microsoft Edge WebView2 Runtime, then try again.",
                "TV Browser");
            Close();
            return;
        }

        var core = _web.CoreWebView2;

        // lock the browser down
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.AreBrowserAcceleratorKeysEnabled = false;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = false;

        // only the launcher and the allowed streaming sites can be opened
        core.NavigationStarting += (_, e) => { if (!IsAllowed(e.Uri)) e.Cancel = true; };

        // links that want a new window open in this same window instead
        core.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;
            if (IsAllowed(e.Uri)) core.Navigate(e.Uri);
        };

        core.DownloadStarting += (_, e) => e.Cancel = true;

        core.PermissionRequested += (_, e) =>
        {
            e.State = e.PermissionKind switch
            {
                CoreWebView2PermissionKind.Camera or
                CoreWebView2PermissionKind.Microphone or
                CoreWebView2PermissionKind.Geolocation or
                CoreWebView2PermissionKind.Notifications => CoreWebView2PermissionState.Deny,
                _ => CoreWebView2PermissionState.Default
            };
        };

        // if the page crashes, reload it
        core.ProcessFailed += (_, e) =>
        {
            if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited) core.Reload();
        };

        // keys that work on every site, even during fullscreen video
        InstallKeyHook();

        // the Home button shown in the top left of every page
        await core.AddScriptToExecuteOnDocumentCreatedAsync(
            HomeButtonScript.Replace("__HOME__", JsonSerializer.Serialize(_home.ToString())));

        core.Navigate(_home.ToString());
    }

    // ---- global key hook: Home / remote Home button / quit keys, only while this window is in front ----
    private const int WH_KEYBOARD_LL = 13, WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104;
    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
    private LowLevelKeyboardProc? _hookProc;   // kept in a field so it isn't garbage collected
    private IntPtr _hook = IntPtr.Zero;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int vKey);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr GetModuleHandle(string? lpModuleName);

    private void InstallKeyHook()
    {
        _hookProc = HookCallback;
        using var proc = Process.GetCurrentProcess();
        _hook = SetWindowsHookEx(WH_KEYBOARD_LL, _hookProc, GetModuleHandle(proc.MainModule?.ModuleName), 0);
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN) &&
            GetForegroundWindow() == Handle)
        {
            var key = (Keys)Marshal.ReadInt32(lParam);          // first field of KBDLLHOOKSTRUCT is the key code
            bool alt = (GetAsyncKeyState((int)Keys.Menu) & 0x8000) != 0;
            bool ctrl = (GetAsyncKeyState((int)Keys.ControlKey) & 0x8000) != 0;

            if (key == Keys.BrowserHome || (key == Keys.Home && alt))
            {
                BeginInvoke(new Action(GoHome));
                return (IntPtr)1;                               // swallow the key
            }
            if ((key == Keys.F4 && alt) || (key == Keys.Q && ctrl && alt))
            {
                BeginInvoke(new Action(Close));
                return (IntPtr)1;
            }
        }
        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        if (_hook != IntPtr.Zero) UnhookWindowsHookEx(_hook);
        base.OnFormClosed(e);
    }

    private void GoHome() => _web.CoreWebView2.Navigate(_home.ToString());

    private bool IsAllowed(string uri)
    {
        if (!Uri.TryCreate(uri, UriKind.Absolute, out var u)) return false;
        if (u.Scheme == "about") return true;
        if (u.Scheme != Uri.UriSchemeHttps && u.Scheme != Uri.UriSchemeHttp) return false;

        var host = u.Host.ToLowerInvariant();
        if (host == _home.Host.ToLowerInvariant()) return true;

        foreach (var d in _cfg.AllowedDomains)
        {
            var domain = d.Trim().TrimStart('.').ToLowerInvariant();
            if (domain.Length == 0) continue;
            if (host == domain || host.EndsWith("." + domain)) return true;
        }
        return false;
    }

    private const string HomeButtonScript = """
    (() => {
      if (window.top !== window) return;
      const HOME = __HOME__;
      const add = () => {
        if (location.href.startsWith('about:') || location.href.startsWith(HOME)) return;
        if (document.getElementById('tv-home-button-host')) return;
        const host = document.createElement('div');
        host.id = 'tv-home-button-host';
        host.style.cssText = 'all:initial;position:fixed;top:14px;left:14px;z-index:2147483647;';
        const root = host.attachShadow({ mode: 'closed' });
        root.innerHTML = `
          <style>
            button {
              all: initial; box-sizing: border-box; width: 52px; height: 52px; border-radius: 50%;
              display: grid; place-items: center; cursor: pointer; color: #fff;
              background: rgba(18, 20, 28, .72); border: 2px solid rgba(255, 255, 255, .28);
              backdrop-filter: blur(6px); opacity: .4; transition: opacity .15s, transform .15s;
            }
            button:hover, button:focus-visible { opacity: 1; transform: scale(1.08); outline: 3px solid #fff; }
            svg { width: 26px; height: 26px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
          </style>
          <button type="button" aria-label="Home">
            <svg viewBox="0 0 24 24"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M10 20v-6h4v6"/></svg>
          </button>`;
        root.querySelector('button').addEventListener('click', () => { location.href = HOME; });
        document.documentElement.append(host);
      };
      window.addEventListener('keydown', e => {
        if (e.key === 'BrowserHome') { e.preventDefault(); location.href = HOME; }
      }, true);
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', add);
      else add();
    })();
    """;
}
