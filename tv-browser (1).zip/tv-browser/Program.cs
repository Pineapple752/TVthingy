namespace TVBrowser;

static class Program
{
    [STAThread]
    static void Main()
    {
        // only one copy at a time
        using var mutex = new Mutex(true, "TVBrowser-single-instance", out bool isFirst);
        if (!isFirst) return;

        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
