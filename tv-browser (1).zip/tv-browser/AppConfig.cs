using System.Text.Json;

namespace TVBrowser;

sealed class AppConfig
{
    public string HomeUrl { get; set; } = "https://pineapple752.github.io/tv-launcher/";

    public string[] AllowedDomains { get; set; } =
    {
        "youtube.com", "youtu.be", "google.com", "googlevideo.com", "ytimg.com",
        "netflix.com", "primevideo.com", "amazon.com", "disneyplus.com", "disney.com",
        "hulu.com", "hbomax.com", "max.com", "hbo.com", "apple.com", "paramountplus.com",
        "peacocktv.com", "twitch.tv", "crunchyroll.com", "spotify.com", "plex.tv",
        "tubitv.com", "pluto.tv"
    };

    // reads config.json from the folder next to TVBrowser.exe; falls back to the defaults above
    public static AppConfig Load()
    {
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "config.json");
            if (File.Exists(path))
            {
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                };
                return JsonSerializer.Deserialize<AppConfig>(File.ReadAllText(path), options) ?? new AppConfig();
            }
        }
        catch
        {
            // a broken config file shouldn't stop the app from starting
        }
        return new AppConfig();
    }
}
