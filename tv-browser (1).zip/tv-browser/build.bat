@echo off
cd /d "%~dp0"
echo Building TV Browser...
dotnet publish TVBrowser.csproj -c Release -o publish
if errorlevel 1 (
  echo.
  echo The build failed. Copy the red error text above and send it back.
  pause
  exit /b 1
)
echo.
echo Done. Run publish\TVBrowser.exe
pause
