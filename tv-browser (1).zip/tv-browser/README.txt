TV Browser: a full screen, locked down browser for your TV launcher.

1. Install the .NET 10 SDK:      winget install Microsoft.DotNet.SDK.10
2. Double-click build.bat
3. Run publish\TVBrowser.exe

Edit publish\config.json to change the launcher address or the allowed sites.
Keys:  Home / remote Home button / Alt+Home = back to the launcher
       Alt+F4 or Ctrl+Alt+Q = quit
